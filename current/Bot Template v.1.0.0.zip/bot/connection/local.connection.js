const bot = require("./token.connection");

module.exports = bot.launch();